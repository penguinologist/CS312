package penguinologist.quizgame;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class createsaquestion extends ActionBarActivity {
    EditText question;
    EditText answer;
    Button submit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_createsaquestion);


         question = (EditText) findViewById(R.id.editText3);
         answer = (EditText) findViewById(R.id.editText4);
         submit = (Button) findViewById(R.id.button11);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//TODO do the actual submitting of the input to the gradeserver

                if(question.getText().length()>0 && answer.getText().length()>0) {
                    Log.e("asldflkjasd","answer recorded");
                    startActivity(new Intent(createsaquestion.this, MainPage.class));
                    finish();
                }
                else{
                    Toast toast = Toast.makeText(getApplicationContext(), "the fields cannot be empty", Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        });


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_createsaquestion, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
