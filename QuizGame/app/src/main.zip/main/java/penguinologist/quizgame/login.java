package penguinologist.quizgame;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import java.io.File;


public class login extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Button submit = (Button)findViewById(R.id.button);






        /*this is used to start the Grade Server; normally the server would
		* run on its own and would not be part of this application. */
        CONNECT_TO_GRADE_SERVER();





        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(validLogin()) {
                    startActivity(new Intent(login.this, MainPage.class));
                }
                else{
                    //set the text to show wrong input

                }
            }
        });





    }




    public static void CONNECT_TO_GRADE_SERVER(){
        //Ideally the Grade Server would be an external system, not a thread running in this
        //application.
        (new Thread(new GradeServer())).start();
    }


    private boolean validLogin() {
//check if user exists in db
        /*File file;
        try {
            file = new File("database.txt");
        } catch (Exception E) {
            return false;

        }*/
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_login, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
